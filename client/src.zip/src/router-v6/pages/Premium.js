import Footer from "../../components/footer/Footer";
import Pro from "../../components/UI/Pro/Pro";

const Premium = () => {
  return (
    <>
      <Pro />
      <Footer />
    </>
  );
};

export default Premium;

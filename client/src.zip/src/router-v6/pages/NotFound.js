const NotFound = () => {
  return <h1>page not found</h1>;
};

export default NotFound;

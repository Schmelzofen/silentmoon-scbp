const LidBackground = (props) => {
  return <img src={props.src} alt="album cover" />;
};

export default LidBackground;

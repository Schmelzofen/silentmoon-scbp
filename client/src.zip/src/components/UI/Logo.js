import classes from "./Logo.module.css";

const Logo = () => {
  return <h3 className={classes.logo}>SILENT MOON</h3>;
};

export default Logo;

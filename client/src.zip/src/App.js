import MainRoutes from "./router-v6/routes/MainRoutes";

function App() {
  return (
    <>
      <MainRoutes />
    </>
  );
}

export default App;
